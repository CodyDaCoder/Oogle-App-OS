var search;
onEvent("button1", "click", function( ) {
  setScreen("screen2");
});
onEvent("button2", "click", function( ) {
  setScreen("screen3");
  search = getText("text_input1");
  if (search == "YouTube") {
    showElement("button3");
  }
});
onEvent("button3", "click", function( ) {
  setScreen("screen4");
});
onEvent("button4", "click", function( ) {
  setScreen("screen5");
  
});
onEvent("button6", "click", function( ) {
  setScreen("screen6");
  
});
